# HoverFlow

Utilidad para Windows 10/11 que amplía temporalmente una ventana al mantener el cursor encima y la devuelve a su posición y tamaño anteriores al salir. La ampliación deja un margen visible y configurable alrededor; no usa el estado de maximización de Windows. Pensada para convivir con PowerToys FancyZones.

## Ejecutar

1. Instala [AutoHotkey v2](https://www.autohotkey.com/). La versión 1 no es compatible.
2. Descarga este proyecto y abre `HoverFlow.ahk`.
3. Ajusta los tiempos y el margen en píxeles y pulsa **Guardar ajustes**. Puedes cerrar la ventana de ajustes: HoverFlow sigue en la bandeja del sistema.
4. Para cerrar el programa, usa **Salir** en el menú de la bandeja.

El margen inicial es de **24 px**, el tiempo de ampliación **400 ms** y el de restauración **650 ms**. Se aceptan márgenes entre 8 y 200 px; tiempos de 100 a 2500 ms para ampliar y de 100 a 3000 ms para restaurar. Los ajustes persisten en `%APPDATA%\HoverFlow\settings.ini`.

## Comportamiento

- Al posar el cursor sobre una ventana normal, espera el tiempo configurado y la mueve al área de trabajo del monitor donde está el cursor, descontando el margen por los cuatro lados.
- Al salir del rectángulo ampliado, espera el tiempo configurado y restaura sus coordenadas y dimensiones. Si el cursor vuelve antes, cancela la restauración.
- `Ctrl + Alt + Espacio` fija o libera temporalmente la ventana ampliada.
- Mientras una ventana esté ampliada no se amplía otra; al restaurarse, puede activarse otra ventana bajo el cursor.
- Omite ventanas minimizadas, maximizadas, sin barra de título, demasiado pequeñas y ventanas de herramientas. Detiene el seguimiento durante arrastres con botones del ratón.
- Desactivar la función, elegir **Restaurar ventana** o salir del programa restaura la ventana que HoverFlow haya ampliado.

### FancyZones y varios monitores

HoverFlow guarda las coordenadas de la ventana antes de moverla y las recupera al restaurar; esto permite regresar al lugar que ocupaba en FancyZones. El área disponible excluye la barra de tareas mediante `MonitorGetWorkArea`. El margen se interpreta en las coordenadas de pantalla que usa AutoHotkey; en configuraciones con escalado DPI distinto entre monitores conviene verificar visualmente el tamaño resultante.

### Limitaciones conocidas

- Algunos programas con ventanas personalizadas, restricciones de tamaño o permisos de administrador pueden impedir el movimiento o alterar la posición restaurada. Para manejar una aplicación elevada, AutoHotkey también debe ejecutarse con los permisos apropiados.
- El borde visible permite salir de la ventana, pero la barra de tareas u otras ventanas superpuestas pueden ocupar parte de él.
- Si cambias manualmente el tamaño de una ventana mientras está ampliada, al salir se restaurará la geometría capturada antes de ampliar.
- Esta versión usa un único margen uniforme y una ventana ampliada a la vez; no incluye una lista de exclusiones editable.

## Crear un ejecutable

En Windows, instala AutoHotkey v2 con Ahk2Exe, haz clic derecho en `HoverFlow.ahk` y selecciona **Compile Script**. También puedes abrir Ahk2Exe, seleccionar el script y compilarlo. El ejecutable resultante se puede usar sin instalar AutoHotkey en el equipo de destino. Distribuye el código fuente y la licencia junto al binario.

## Estructura

`HoverFlow.ahk`: interfaz, configuración, temporizadores, detección de monitor y control de ventanas. `LICENSE`: licencia MIT.

## Desarrollo y pruebas manuales

En Windows, abre dos ventanas en FancyZones: comprueba ampliación, salida por los cuatro lados, retorno a la zona, cancelación al volver el cursor, bloqueo con el atajo, activación de otra ventana, bandeja, reinicio y monitores adicionales. Prueba también con la barra de tareas visible y con un margen de 8 y de 200 px.

Esta entrega se preparó fuera de Windows; el comportamiento de ventanas y la compilación del `.exe` requieren validación en Windows.
