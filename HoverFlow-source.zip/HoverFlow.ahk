#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent

; HoverFlow: window expansion within the monitor work area.
CoordMode "Mouse", "Screen"
SetWinDelay -1
global settingsPath := A_AppData "\HoverFlow\settings.ini"
global enabled := true, hoverMs := 400, restoreMs := 650, margin := 24
global hoverHwnd := 0, hoverSince := 0, expandedHwnd := 0, outsideSince := 0
global original := Map(), locked := false, guiHwnd := 0
global excluded := Map()
LoadSettings()
BuildGui()
SetTimer WatchWindows, 50

LoadSettings() {
    global settingsPath, enabled, hoverMs, restoreMs, margin
    enabled := IniRead(settingsPath, "General", "Enabled", 1) = "1"
    hoverMs := Clamp(IniRead(settingsPath, "General", "HoverMs", 400), 100, 2500)
    restoreMs := Clamp(IniRead(settingsPath, "General", "RestoreMs", 650), 100, 3000)
    margin := Clamp(IniRead(settingsPath, "General", "Margin", 24), 8, 200)
}

Clamp(value, low, high) {
    try return Max(low, Min(high, Integer(value)))
    catch return low
}

BuildGui() {
    global ui, guiHwnd, enabled, hoverMs, restoreMs, margin, toggle, hoverEdit, restoreEdit, marginEdit, status
    ui := Gui("+AlwaysOnTop", "HoverFlow")
    ui.BackColor := "F7F9FC"
    ui.SetFont("s11 c172B4D", "Segoe UI")
    ui.AddText("x22 y17 w320", "HOVERFLOW")
    ui.SetFont("s9 c526273", "Segoe UI")
    ui.AddText("x22 y45 w320", "Amplía ventanas al posar el cursor y restaura al salir.")
    toggle := ui.AddCheckbox("x22 y84 w325", "Activar expansión automática")
    toggle.Value := enabled
    toggle.OnEvent("Click", (*) => UpdateSettings())
    ui.AddText("x22 y124 w240", "Espera para ampliar (ms)")
    hoverEdit := ui.AddEdit("x270 y120 w76 Number", hoverMs)
    ui.AddText("x22 y164 w240", "Espera para restaurar (ms)")
    restoreEdit := ui.AddEdit("x270 y160 w76 Number", restoreMs)
    ui.AddText("x22 y204 w240", "Margen de salida (px)")
    marginEdit := ui.AddEdit("x270 y200 w76 Number", margin)
    ui.AddText("x22 y244 w325 c64748B", "Deja visible un borde alrededor de la ventana.")
    ui.AddButton("x22 y279 w324 h34 Default", "Guardar ajustes").OnEvent("Click", (*) => UpdateSettings())
    status := ui.AddText("x22 y328 w324", "Ctrl + Alt + Espacio: fijar o liberar ventana")
    ui.OnEvent("Close", (*) => ui.Hide())
    ui.Show("w370 h365")
    guiHwnd := ui.Hwnd
    A_TrayMenu.Delete()
    A_TrayMenu.Add("Abrir ajustes", (*) => ui.Show())
    A_TrayMenu.Add("Restaurar ventana", (*) => RestoreWindow())
    A_TrayMenu.Add("Salir", (*) => ExitApp())
    A_TrayMenu.Default := "Abrir ajustes"
}

UpdateSettings() {
    global settingsPath, enabled, hoverMs, restoreMs, margin, toggle, hoverEdit, restoreEdit, marginEdit, status
    enabled := toggle.Value = 1
    hoverMs := Clamp(hoverEdit.Value, 100, 2500)
    restoreMs := Clamp(restoreEdit.Value, 100, 3000)
    margin := Clamp(marginEdit.Value, 8, 200)
    hoverEdit.Value := hoverMs, restoreEdit.Value := restoreMs, marginEdit.Value := margin
    DirCreate(A_AppData "\HoverFlow")
    IniWrite(enabled ? 1 : 0, settingsPath, "General", "Enabled")
    IniWrite(hoverMs, settingsPath, "General", "HoverMs")
    IniWrite(restoreMs, settingsPath, "General", "RestoreMs")
    IniWrite(margin, settingsPath, "General", "Margin")
    if !enabled
        RestoreWindow()
    status.Text := "Ajustes guardados"
}

^!Space:: {
    global locked, expandedHwnd, status
    if !expandedHwnd
        return
    locked := !locked
    status.Text := locked ? "Ventana fijada" : "Ventana liberada"
}

WatchWindows() {
    global enabled, hoverHwnd, hoverSince, hoverMs, restoreMs, expandedHwnd, outsideSince, locked
    if !enabled || GetKeyState("LButton", "P") || GetKeyState("RButton", "P")
        return
    MouseGetPos &x, &y, &hwnd
    now := A_TickCount
    if expandedHwnd {
        if !WinExist("ahk_id " expandedHwnd) {
            ClearState()
            return
        }
        if locked || PointInside(expandedHwnd, x, y) {
            outsideSince := 0
            return
        }
        if !outsideSince
            outsideSince := now
        else if now - outsideSince >= restoreMs
            RestoreWindow()
        return
    }
    if !Eligible(hwnd) {
        hoverHwnd := 0
        return
    }
    if hwnd != hoverHwnd {
        hoverHwnd := hwnd
        hoverSince := now
    } else if now - hoverSince >= hoverMs {
        ExpandWindow(hwnd)
        hoverHwnd := 0
    }
}

Eligible(hwnd) {
    global guiHwnd, excluded
    if !hwnd || hwnd = guiHwnd || excluded.Has(hwnd)
        return false
    try {
        if WinGetMinMax("ahk_id " hwnd) != 0
            return false
        if !(WinGetStyle("ahk_id " hwnd) & 0xC00000) ; title bar
            return false
        if WinGetExStyle("ahk_id " hwnd) & 0x80 ; tool window
            return false
        if WinGetProcessName("ahk_id " hwnd) = "AutoHotkey64.exe" && hwnd = guiHwnd
            return false
        WinGetPos &wx, &wy, &ww, &wh, "ahk_id " hwnd
        return ww >= 180 && wh >= 100
    } catch return false
}

ExpandWindow(hwnd) {
    global expandedHwnd, original, outsideSince, margin, excluded
    try {
        WinGetPos &wx, &wy, &ww, &wh, "ahk_id " hwnd
        MouseGetPos &mx, &my
        monitor := MonitorFromPoint(mx, my)
        MonitorGetWorkArea monitor, &left, &top, &right, &bottom
        targetW := right - left - 2 * margin
        targetH := bottom - top - 2 * margin
        if targetW < 240 || targetH < 160
            return
        ; Avoid moving an already equally large window and creating a restore loop.
        if Abs(wx - (left + margin)) <= 2 && Abs(wy - (top + margin)) <= 2
            && Abs(ww - targetW) <= 2 && Abs(wh - targetH) <= 2 {
            excluded[hwnd] := true
            return
        }
        original[hwnd] := [wx, wy, ww, wh]
        WinMove left + margin, top + margin, targetW, targetH, "ahk_id " hwnd
        expandedHwnd := hwnd
        outsideSince := 0
    } catch {
        if original.Has(hwnd)
            original.Delete(hwnd)
    }
}

MonitorFromPoint(x, y) {
    count := MonitorGetCount()
    Loop count {
        MonitorGet A_Index, &l, &t, &r, &b
        if x >= l && x < r && y >= t && y < b
            return A_Index
    }
    return MonitorGetPrimary()
}

PointInside(hwnd, x, y) {
    try {
        WinGetPos &wx, &wy, &ww, &wh, "ahk_id " hwnd
        return x >= wx && x < wx + ww && y >= wy && y < wy + wh
    } catch return false
}

RestoreWindow() {
    global expandedHwnd, original
    hwnd := expandedHwnd
    if !hwnd
        return
    if original.Has(hwnd) && WinExist("ahk_id " hwnd) {
        pos := original[hwnd]
        try WinMove pos[1], pos[2], pos[3], pos[4], "ahk_id " hwnd
    }
    ClearState()
}

ClearState() {
    global expandedHwnd, original, outsideSince, hoverHwnd, locked
    original.Clear()
    expandedHwnd := 0, outsideSince := 0, hoverHwnd := 0, locked := false
}

OnExit((*) => RestoreWindow())
