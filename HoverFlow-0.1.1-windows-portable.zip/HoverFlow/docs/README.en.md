# HoverFlow — English quick start

Hover a normal, resizable window to expand it. Move into the exit gutter to restore its original rectangle. Expansion uses the monitor's **work area minus a configurable gutter on all four edges**. It does not maximize the window or move keyboard focus.

Extract the full portable ZIP and run `HoverFlow.exe`. Requires Windows 10 22H2 or Windows 11 with .NET Framework 4.8+. Run as a regular user. Version 0.1.1 is an unsigned preview, tested on Windows x64.

Defaults: 40 DIP gutter, 180 ms hover delay, 140 ms restore delay, 200 ms rearm cooldown. Open Preferences & exclusions, edit process names, then choose Save preferences. After restoration, leave and re-enter the window to rearm.

| Shortcut | Action |
| --- | --- |
| Ctrl + Alt + H | Pause/resume; pausing restores |
| Ctrl + Alt + P | Pin/unpin the current expansion |
| Ctrl + Alt + R | Restore now, including a pinned expansion |

Closing the panel keeps HoverFlow in the tray. Use **Quit and restore** from the tray to exit. Pinning is temporary; it does not make the window always-on-top. Manual resizing, moving, minimizing or maximizing relinquishes control to the user.

The app skips maximized/minimized/full-screen, owned dialog, non-resizable and cloaked windows. Standalone topmost windows are supported without changing their topmost state. Apps with elevated permissions or restrictive size limits may be skipped. Expansion keeps the original Z order; overlapping windows can still cover it.

Version 0.1.1 fixes full-height/full-width FancyZones and Snap layouts: one dimension may decrease to leave the gutter when the overall area grows by at least 5%. Moving to a different window no longer waits for the previous window's cooldown. On the first upgrade, old timing values are capped at 180/140/200 ms without changing gutter or exclusions; faster settings are preserved. Preferences also include a one-click **Use fast timing** button.

Settings and recovery files live in `%LOCALAPPDATA%\HoverFlow`. Recovery after a forced exit runs on the next launch and checks a per-window token before moving anything. No telemetry, updater, startup registration or background service is installed.

FancyZones coexistence is based on rectangle preservation, respecting drag/modifier input and yielding to external changes. Zone membership is not restored, and integration with a running FancyZones installation remains a manual validation item. Mixed-DPI physical monitors also require additional validation; geometry tests cover negative origins and 100–400% scaling.

Build locally without NuGet:

```powershell
.\build.ps1 -Test -NativeTest -Package
```

Full Spanish documentation: [usage](USAGE.es.md), [build and publishing](BUILD.md), [architecture and limitations](ARCHITECTURE.md), [test results](TESTING.md). MIT licensed.
