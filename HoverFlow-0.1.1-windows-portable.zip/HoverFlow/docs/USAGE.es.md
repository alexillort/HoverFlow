# Guía de uso

## El recorrido del cursor

HoverFlow parte de una ventana **normal**, visible y redimensionable. Espera a que el cursor permanezca sobre ella durante el retardo de entrada. La expande al área de trabajo de su monitor, descontando el margen configurado en los cuatro lados. La barra de tareas ya queda fuera del área de trabajo.

El margen se expresa en DIP, unidades independientes del escalado. Un margen de 40 DIP corresponde a 40 píxeles al 100%, 60 al 150% y 80 al 200%. El rango de la interfaz es 16–240 DIP. Si no hay espacio suficiente, se omite la expansión. Una ventana de zona puede reducirse en una dimensión para dejar el margen si su área total aumenta al menos un 5%; esto permite ampliar ventanas que ocupaban toda la altura o anchura de una zona.

Para volver, mueve el cursor fuera de la ventana expandida, hacia el margen, la barra de tareas u otro monitor. El retardo de salida tolera desvíos breves: si regresas antes de que termine, se cancela la restauración. **Restaurar** significa recuperar tamaño y posición; no minimizar a la barra de tareas.

La expansión no activa ni trae al frente la ventana. El foco del teclado permanece donde estaba; haz clic para escribir en otra aplicación. Si prefieres reducir los cambios involuntarios, activa **Only expand the active window**.

## Preferencias

| Preferencia | Predeterminado | Rango / significado |
| --- | --- | --- |
| Exit gutter | 40 DIP | 16–240; espacio de salida en cada borde |
| Hover delay | 180 ms | 50–2000; tiempo continuo antes de expandir |
| Restore delay | 140 ms | 50–2000; tiempo continuo fuera antes de restaurar |
| Rearm cooldown | 200 ms | 50–3000; pausa para la misma ventana después de restaurar |
| Only expand the active window | Desactivado | Solo la ventana que tiene el foco |
| Start paused next time | Desactivado | Se aplica al siguiente inicio |
| Excluded apps | PowerToys, PowerToys.FancyZones, mstsc | Coincidencia exacta del nombre de proceso, sin distinguir mayúsculas |

Las preferencias se aplican al pulsar **Save preferences**. Cambiarlas restaura primero la expansión activa. El margen y los retardos muestran su valor mientras arrastras el control. El cooldown valida números entre 50 y 3000. **Use fast timing** guarda directamente 180/140/200 ms y conserva los demás valores del panel. Al actualizar desde 0.1.0, los tiempos se reducen una sola vez a esos máximos sin alterar el margen ni las exclusiones.

Para excluir una app, abre **Preferences & exclusions** y agrega el nombre que aparece en Administrador de tareas → Detalles; por ejemplo `Code.exe`. Un nombre por línea. No uses rutas, títulos de ventanas ni comodines. `editor.exe` y `EDITOR` equivalen al mismo proceso. Una exclusión afecta todas sus ventanas.

## Evitar oscilaciones

Tras restaurar se exige tanto el cooldown como haber abandonado y vuelto a entrar en la ventana restaurada. Quedarse quieto sobre ella no vuelve a expandirla. La espera de entrada se reinicia si cambia la ventana, su rectángulo o si presionas un botón del ratón/modificador. Solo una ventana puede estar expandida a la vez.

El cooldown afecta a la ventana que acaba de restaurarse. Para ampliar otra ventana basta con su retardo de entrada. El motor consulta cada 25 ms; los tiempos configurados son mínimos, no garantías del tiempo total que tarde una aplicación externa en redimensionarse.

La restauración se suspende mientras se mantiene un botón del ratón, Shift, Ctrl, Alt o Win, durante un movimiento/redimensionamiento del sistema, y sobre menús o ventanas emergentes relacionadas. Esto facilita seleccionar texto, arrastrar y usar menús que salen del borde. No se inyectan teclas ni eventos de ratón.

## Pin y acciones manuales

- **Ctrl + Alt + P** fija/libera la expansión actual. Solo existe un pin; dura esa expansión y no se guarda entre sesiones.
- **Ctrl + Alt + R** restaura inmediatamente, incluso si estaba fijada.
- **Ctrl + Alt + H** pausa y restaura; otra pulsación reanuda.
- Los mismos controles están en el panel y el menú de la bandeja.
- Cerrar el panel con × o Alt+F4 lo oculta. Para terminar: bandeja → **Quit and restore**.

Si mueves, redimensionas, maximizas o minimizas manualmente una ventana expandida, HoverFlow abandona esa expansión y respeta tu cambio. Esto también se aplica si otro gestor de ventanas la recoloca. Un pin no impide los cambios manuales.

## FancyZones y Windows Snap

Puedes colocar tus ventanas en zonas antes de usar HoverFlow. El rectángulo de esa zona pasa a ser el original para ese ciclo. HoverFlow no escribe en la configuración de PowerToys, no envía Win+flechas y no intenta reconstruir el identificador interno de la zona.

Durante un arrastre con Shift o Win no empieza una expansión. Si FancyZones modifica el rectángulo mientras está expandida, HoverFlow conserva ese nuevo rectángulo. Las opciones de FancyZones que recolocan ventanas al cambiar resolución o distribución pueden provocar esa cesión de control. Consulta las [opciones oficiales de FancyZones](https://learn.microsoft.com/en-us/windows/powertoys/fancyzones).

Para comprobar tu configuración: coloca una ventana en una zona, repite varios ciclos de hover y salida, arrástrala a otra zona, y repite. Verifica también Win+flechas y cambios de distribución. Esta versión no ha validado esas operaciones con PowerToys ejecutándose en el equipo de desarrollo.

## Varios monitores y cambios de sesión

Se usa el monitor que contiene la mayor parte de la ventana, no necesariamente el que contiene el cursor. No se expande si el cursor queda fuera del rectángulo de destino. Las coordenadas de monitores situados a la izquierda o arriba del principal pueden ser negativas y se conservan.

Al cambiar el área de trabajo, DPI o monitor, se intenta terminar la expansión. Si desapareció el monitor original, la restauración se limita al área de trabajo disponible. Si Windows ya movió la ventana, se respeta esa recolocación. Por eso no se promete recuperar coordenadas físicamente inaccesibles tras desconectar un monitor.

Se solicita restauración al bloquear la sesión, desconectarse, suspender o salir. El sistema puede suspender o finalizar el proceso antes de completar la operación; el registro de recuperación es el respaldo.

## Datos locales y recuperación

Los archivos se guardan en `%LOCALAPPDATA%\HoverFlow`:

- `settings.json`: preferencias y exclusiones.
- `settings.json.bak`: versión anterior después de guardar nuevamente.
- `recovery.json`: rectángulo original, destino, monitor y un identificador temporal de ventana; solo mientras hay una operación pendiente.
- `hoverflow.log`: errores técnicos, con rotación al alcanzar aproximadamente 512 KiB.

Antes de mover una ventana se escribe el registro y se añade una propiedad temporal con un token aleatorio al HWND. Al reiniciar HoverFlow, se restaura únicamente si HWND, proceso y token siguen coincidiendo y la geometría sigue siendo la gestionada. Si la ventana cambió manualmente o ya no existe, se descarta el registro. Esto evita actuar sobre otra ventana que haya reutilizado el mismo HWND.

No hay un servicio de vigilancia: tras matar el proceso, la recuperación ocurre **al volver a abrir HoverFlow**, no inmediatamente. Un reinicio de Windows destruye las ventanas; no se intenta recolocar nuevas instancias de las apps.

Si aparece **Restore pending**, espera a que responda la aplicación y pulsa **Restore now**. Mientras esté pendiente, no se inicia otra expansión. Si el archivo de recuperación está mal formado, se conserva y HoverFlow permanece pausado. En ese caso: cierra HoverFlow, coloca manualmente la ventana o cierra la app afectada, copia `recovery.json` para diagnóstico y retíralo de esa carpeta antes de reiniciar. No borres un registro pendiente antes de recuperar tu disposición.

## Solución de problemas

| Síntoma | Comprobación |
| --- | --- |
| No se expande | Ventana normal, redimensionable, no excluida, cursor fuera del margen, no tecla/botón mantenido; salir y volver a entrar |
| Se expande y vuelve enseguida | La app impone un tamaño mínimo o cambia su geometría; aumenta el espacio disponible o exclúyela |
| No se restaura al salir | Revisar pin, menús abiertos, teclas/botones mantenidos y retardo de salida |
| Ventana cubierta después de expandir | HoverFlow conserva el orden de apilamiento; actívala con un clic o usa el modo de ventana activa |
| App ejecutada como administrador | Windows suele bloquear la operación; omítela o ejecútala sin elevación |
| Atajo ocupado | El panel indica cuál; usa los controles de bandeja |
| No ves el icono | Abre la zona de iconos ocultos de Windows; el icono lleva una H violeta |
| App se congela mientras cambia de tamaño | El precontrol omite ventanas ya bloqueadas, pero una app puede bloquearse durante la llamada nativa; ver límites en ARCHITECTURE.md |

Argumentos admitidos: `--tray` inicia con el panel oculto; `--paused` inicia pausado. Pueden combinarse. No se configura el inicio automático; puedes crear por tu cuenta un acceso directo con esos argumentos si lo deseas.
