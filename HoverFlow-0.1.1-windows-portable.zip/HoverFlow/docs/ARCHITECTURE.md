# Arquitectura

## Componentes

| Archivo | Responsabilidad |
| --- | --- |
| `Core.cs` | Geometría en píxeles, preferencias normalizadas y máquina de estados sin dependencias de Windows |
| `Native.cs` | Interoperabilidad Win32, clasificación, identidad de ventana, expansión/restauración y recuperación |
| `Storage.cs` | JSON, escritura temporal con flush y reemplazo, copia anterior y log limitado |
| `Program.cs` | Ciclo de vida WPF, bandeja WinForms, atajos, eventos de sesión y conexión con el motor |
| `MainWindow.xaml` | Interfaz declarativa embebida como recurso; se carga con XamlReader |
| `Tests.cs` | Motor con escritorio falso y pruebas nativas sobre una ventana auxiliar propia |

La aplicación usa C# compatible con el compilador de .NET Framework, WPF y P/Invoke. No instala paquetes de NuGet. Se eligió .NET Framework 4.8 para poder compilar y distribuir con los componentes ya presentes en el entorno. No es una aplicación WinUI ni un servicio.

## Máquina de estados

```mermaid
stateDiagram-v2
    [*] --> Ready
    Ready --> Dwell: ventana elegible y cursor dentro del destino
    Dwell --> Ready: salida, interacción o rectángulo cambiado
    Dwell --> Expanded: retardo cumplido y expansión verificada
    Expanded --> ExitDelay: cursor fuera
    ExitDelay --> Expanded: cursor vuelve o interacción
    ExitDelay --> Cooldown: retardo cumplido y restauración verificada
    Expanded --> Pinned: fijar
    Pinned --> Expanded: liberar
    Pinned --> Cooldown: restaurar o pausar
    Expanded --> Cooldown: cambio manual; ceder control
    Cooldown --> Dwell: tiempo cumplido y nuevo ingreso
    Expanded --> Pending: restauración fallida
    Pending --> Cooldown: restauración reintentada
```

El reloj es monotónico (`Stopwatch`). El temporizador consulta el cursor cada 25 ms en el dispatcher; los retardos son mínimos y pueden superar el valor configurado hasta un tick más el tiempo de procesamiento. No se usan hooks globales de teclado/ratón, inyección ni activación de ventanas. Los atajos usan `RegisterHotKey` con `MOD_NOREPEAT`.

`IDesktop` permite probar el motor con tiempo, cursor y estados de ventanas inyectados. Solo existe una expansión activa y un candidato. Una ventana restaurada queda bloqueada hasta que se haya salido y vuelto a entrar, además de esperar el cooldown de la misma ventana.

## Coordenadas, DPI y geometría

El manifiesto declara PerMonitorV2. `GetWindowRect` y `SetWindowPos` trabajan en coordenadas físicas del escritorio desde este proceso. El destino es `MONITORINFO.rcWork` insetado por `ceil(gutterDip * monitorDpi / 96)`. `GetDpiForMonitor` obtiene el DPI del monitor incluso si la app objetivo es DPI unaware; `GetDpiForWindow` es respaldo. Las pruebas físicas disponibles fueron a 96 DPI; la matriz mixta sigue pendiente.

El rectángulo guardado incluye los bordes de redimensionamiento invisibles de Windows. Esto puede dejar algo más de espacio visual que el margen pedido. No se pasa un rectángulo de DWM a `SetWindowPos`.

Se captura `WINDOWPLACEMENT` para diagnóstico, pero la restauración usa el rectángulo físico original. Solo se expanden ventanas normales. `rcNormalPosition` tiene coordenadas de **workspace**, por lo que no se pasa a `SetWindowPos`; así se evita el desplazamiento progresivo cuando la barra de tareas está arriba o a la izquierda. No se llama a maximizar ni se simula doble clic.

Referencias primarias: [GetWindowRect](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getwindowrect), [WINDOWPLACEMENT](https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-windowplacement), [DPI en aplicaciones de escritorio](https://learn.microsoft.com/en-us/windows/win32/hidpi/high-dpi-desktop-application-development-on-windows).

## Transacción y recuperación

1. Comprobar elegibilidad y que el rectángulo no cambió desde la inspección.
2. Añadir una propiedad `HoverFlow.<GUID>` al HWND con token aleatorio. La operación también detecta restricciones de acceso de Windows.
3. Guardar `recovery.json` y hacer flush antes del movimiento.
4. Aplicar el destino con `SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOOWNERZORDER`.
5. Verificar que el rectángulo efectivo coincide exactamente. Si la app lo restringe, registrar lo observado e intentar rollback.
6. Al salir, validar HWND + PID + propiedad/token y restaurar el rectángulo original.
7. Eliminar registro y propiedad solo al resolver la operación, o al ceder a un cambio manual/ventana destruida.

La identidad no se basa solo en PID y HWND: ambos pueden reciclarse. La propiedad desaparece cuando Windows destruye la ventana. Los archivos de recuperación no se reutilizan después de reiniciar Windows para reposicionar ventanas nuevas.

El criterio de «cambio manual» es una diferencia de más de dos píxeles o un cambio visible de estado. Es conservador: una app que se redimensiona a sí misma se trata igual que una acción del usuario. Se prioriza respetar el cambio ajeno sobre forzar coordenadas antiguas. Tras un cambio de topología se limita el original al área disponible cuando sigue siendo seguro restaurar.

## Límites deliberados

- `SetWindowPos` es síncrono para impedir que un movimiento encolado se ejecute después de haber finalizado un rollback. Se omiten ventanas ya identificadas como bloqueadas. Una aplicación que se bloquee justo durante la llamada puede demorar la interfaz de HoverFlow; los 300 ms de verificación no son un timeout de la llamada Win32. Una evolución posible es aislar estas operaciones en un proceso auxiliar con protocolo y journal de operaciones pendientes.
- No se garantiza el rollback si la app impone nuevas restricciones, pierde permisos o se cierra. Se conserva el registro y se pausa cuando la restauración falla.
- Un cierre forzado en el breve intervalo entre un tamaño rechazado y la actualización del registro puede dejar un rectángulo que se interpreta como cambio ajeno. Se evita restaurar sobre una geometría desconocida.
- El journal no garantiza recuperación inmediata ni supervivencia a daños del disco; no hay watchdog ni servicio residente aparte del proceso.
- Se conserva geometría, no el historial de Snap/FancyZones, el estado interno de la app, ni el orden de apilamiento después de acciones externas.
- No se cambia el foco al hacer hover. La ventana puede quedar parcialmente cubierta por otra.
- Las pruebas de hardware mixto, docking, escritorio remoto y aplicaciones con diseños especiales siguen siendo necesarias.

## Privacidad

No hay llamadas de red en el programa. El motor lee nombre de proceso, estilo, monitor y rectángulo. No lee contenido de documentos, texto escrito, portapapeles ni títulos de ventanas. Los registros técnicos pueden contener rutas locales y mensajes de error; revísalos antes de adjuntarlos a una incidencia.
