# Instalación, compilación y distribución

## Usar el ZIP portátil

1. Extrae `HoverFlow-0.1.1-windows-portable.zip` completo.
2. Conserva `HoverFlow.exe.config` junto a `HoverFlow.exe`.
3. Ejecuta `HoverFlow.exe` como usuario normal.

Objetivo: Windows 10 22H2 o Windows 11 y .NET Framework 4.8 o superior. El binario es AnyCPU; se probó en Windows x64. ARM64 no está validado. El runtime de .NET moderno (8/10) por sí solo no reemplaza .NET Framework.

No modifica el registro para iniciar con Windows ni instala servicios. Para actualizar: bandeja → **Quit and restore**, extraer la versión nueva en otra carpeta y abrirla. Las preferencias permanecen en `%LOCALAPPDATA%\HoverFlow`. Para desinstalar: salir restaurando, borrar la carpeta extraída y, si ya no hay una recuperación pendiente, borrar opcionalmente la carpeta de preferencias. No borres archivos mientras HoverFlow está funcionando.

## Compilación sin descargas

El camino de referencia es `build.ps1`, compatible con Windows PowerShell 5.1 y PowerShell 7. Invoca el compilador instalado en `%WINDIR%\Microsoft.NET\Framework64\v4.0.30319` (o Framework en x86) y las bibliotecas WPF del equipo. Requiere .NET Framework 4.8+; no necesita paquetes externos, NuGet ni acceso a Internet.

```powershell
.\build.ps1                         # Programa
.\build.ps1 -Test                   # Programa y pruebas del motor
.\build.ps1 -Test -NativeTest       # Añade pruebas Win32 y smoke test WPF
.\build.ps1 -Test -NativeTest -Package
.\package-source.ps1               # ZIP de código, incluidas las carpetas .github
```

Se tratan las advertencias del compilador como errores. La opción `-Package` ejecuta las pruebas del motor antes de comprimir. `-NativeTest` requiere una sesión de escritorio Windows disponible y abre únicamente una ventana auxiliar de prueba. No uses una sesión bloqueada para validar comportamiento de ventanas.

Salida:

```text
artifacts/
  HoverFlow/                         # Carpeta ejecutable portátil
    HoverFlow.exe
    HoverFlow.exe.config
    README.md, LICENSE, docs/, assets/
  HoverFlow.Tests.exe
  test-results.txt                   # Última ejecución con pruebas
  native-test-results.txt            # Solo con -NativeTest
  smoke/                            # Preferencias aisladas de prueba
  HoverFlow-0.1.1-windows-portable.zip
  HoverFlow-0.1.1-windows-portable.zip.sha256
```

Si la política local bloquea scripts, revisa el contenido y ejecuta con una excepción solo para ese proceso:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build.ps1 -Test -NativeTest -Package
```

## Visual Studio / MSBuild

Abre `HoverFlow.sln` con Visual Studio y los componentes de desarrollo de escritorio .NET y targeting pack de .NET Framework 4.8. Compila **Release / Any CPU**. También:

```powershell
msbuild .\HoverFlow.sln /p:Configuration=Release
```

El proyecto usa XAML embebido, cargado por `XamlReader`, sin código generado de WPF. El script directo es la vía probada en el entorno de entrega; la solución estándar requiere el targeting pack, que no estaba instalado allí. No se incluye un proyecto de pruebas NuGet: el runner propio se compila mediante `build.ps1`.

## Verificación del paquete

```powershell
Get-FileHash .\HoverFlow-0.1.1-windows-portable.zip -Algorithm SHA256
```

Compara el resultado con el archivo `.sha256` de la misma entrega. La compilación del compilador clásico contiene metadatos variables; no se promete reproducibilidad binaria idéntica entre equipos.

## Preparar GitHub

El ZIP de código fuente incluye archivos ocultos como `.github/` y `.gitignore`. Extrae todo y usa esa carpeta como raíz. No se ha creado ni publicado un repositorio remoto en tu nombre.

```powershell
git init -b main
git add .
git commit -m "Initial HoverFlow desktop app"
```

Después crea un repositorio vacío en tu cuenta, sin README automático, y utiliza la URL real que te muestre GitHub:

```powershell
git remote add origin <URL_DE_TU_REPOSITORIO>
git push -u origin main
```

`artifacts/`, `bin/`, `obj/`, preferencias, logs y archivos de usuario están excluidos. Revisa siempre `git status` antes de publicar. La licencia MIT usa «HoverFlow contributors»; puedes añadir tu atribución antes del primer lanzamiento.

## Integración continua y release

`.github/workflows/build.yml` compila, ejecuta pruebas del motor y genera el ZIP en un runner Windows para pushes, PRs o ejecuciones manuales. Sube los resultados como artefacto de Actions. Las pruebas nativas no se incluyen en CI porque requieren un escritorio interactivo; ejecútalas localmente antes de una release. El workflow se proporciona, pero no se ha ejecutado en GitHub durante esta entrega.

Para publicar: ejecutar pruebas locales, revisar `docs/TESTING.md`, actualizar versión en `AssemblyInfo.cs`, `app.manifest`, `HoverFlow.csproj`, `build.ps1`, documentación y changelog; crear una etiqueta y una release desde GitHub; adjuntar ZIP portátil y hash. Para distribución pública amplia, obtener un certificado y firmar el ejecutable con SignTool **antes** de comprimir y recalcular el hash. Esta entrega no está firmada.

## Herramientas de desarrollo incluidas

```powershell
.\artifacts\HoverFlow\HoverFlow.exe --preview C:\ruta\preview.png
.\artifacts\HoverFlow\HoverFlow.exe --smoke-test C:\ruta\carpeta-de-prueba
```

`--preview` renderiza el XAML sin activar el motor. `--smoke-test` usa la carpeta indicada, inicia pausado con sondeo desactivado, comprueba controles y persistencia y termina. No uses tu carpeta real de preferencias como carpeta de prueba. Estos argumentos son para desarrollo; `--tray` y `--paused` son los argumentos de uso habitual.

Puedes añadir `--compact --expanded` a `--preview` para comprobar preferencias en un render de 700 × 560 píxeles, desplazado hasta el final del panel.
