# Pruebas de la entrega 0.1.1

Validación completada el **7 de octubre de 2026**. Este documento distingue pruebas ejecutadas de capacidades implementadas que todavía requieren validación manual.

## Entorno

- Windows x64, build 26200.9457 (25H2).
- .NET Framework instalado: 4.8.09221; valor Release 533509 (runtime 4.8.1).
- Compilador clásico de Framework, advertencias tratadas como errores.
- Pruebas Win32 sobre un monitor con DPI 96, área de trabajo `0,0–1920,1152`.
- La ventana auxiliar inicial medía 380 × 260 píxeles en `100,100`.
- No se descargaron dependencias ni se modificaron las ventanas del usuario.

## Resultados ejecutados

| Grupo | Resultado | Cobertura |
| --- | --- | --- |
| Compilación por `build.ps1` | Correcta, sin advertencias | Aplicación y runner de pruebas |
| Motor, geometría y persistencia | **38/38** | Retardos, geometría de zonas, migración de tiempos, exclusiones, pin, cooldown, manual override, errores y journal inválido |
| Geometría generada | **10.000 casos dentro de la suite** | Orígenes negativos/positivos, tamaño variable, margen, DPI 96–384 y cuatro bordes libres |
| Integración nativa | **12/12** | HWND real de proceso auxiliar, expansión, zona de altura completa, topmost, foco, restricciones y restauración |
| Repetición de restauración | **20 ciclos sin deriva** | Coincidencia exacta del rectángulo físico original en cada ciclo |
| Smoke test WPF | Correcto | Construcción del panel y bandeja, persistencia, validación, botones, pausa desde bandeja, mensaje de restauración, ocultar y liberar recursos |
| Render del XAML | Inspeccionado | Vista principal y preferencias en ventana compacta con desplazamiento |
| Código extraído del ZIP | Correcto | 38/38 pruebas después de compilar desde carpeta limpia con Windows PowerShell 5.1 |
| Portátil extraído del ZIP | Correcto | Smoke test WPF y hash del ejecutable coincidente con el binario compilado |
| Archivos del repositorio | Comprobados | Archivos ocultos de GitHub presentes, XML válido y enlaces locales de documentación resueltos |

Las 12 pruebas nativas comprueban: clasificación y DPI; expansión/foco/margen; 20 ciclos exactos; recuperación al recrear el backend leyendo el journal; rollback por tamaño mínimo; preservación de movimiento manual; restauración parcial pendiente y reintento; minimización conservada; exclusión de maximizada; expansión y restauración exacta de una zona de altura completa; conservación del estado topmost; rechazo de un token de identidad retirado.

Las proporciones de zonas se reproducen en una ventana auxiliar. No se han movido las ventanas reales de Edge, Chrome, ChatGPT o Spark del usuario; la comprobación conjunta con FancyZones ejecutándose sigue pendiente.

La prueba de recuperación recrea el backend mientras la ventana auxiliar sigue viva; **no** equivale a una prueba de corte de energía ni de cierre forzado en todas las instrucciones posibles. El smoke test llama los controles WPF reales, pero desactiva el sondeo de ventanas del usuario. El despacho del mensaje de atajo se comprueba internamente; no se simulan pulsaciones del teclado físico.

## Cómo reproducir

```powershell
.\build.ps1 -Test -NativeTest -Package
```

La consola y `artifacts/test-results.txt` / `native-test-results.txt` muestran cada resultado. Los marcadores y preferencias del smoke test quedan bajo `artifacts/smoke/<id>/`. El proceso auxiliar de las pruebas nativas cierra automáticamente a los 45 segundos como respaldo. Si una prueba falla, el script no genera una nueva distribución válida.

## Compilación alternativa no validada

Se intentó abrir la vía MSBuild de `HoverFlow.sln`, pero el equipo no dispone de los ensamblados de referencia de .NET Framework 4.8 (MSB3644). La solución está incluida para equipos con ese targeting pack. El binario entregado proviene del script directo, que sí compiló y pasó las pruebas. El workflow de GitHub Actions se incluye sin haberlo ejecutado en GitHub.

## Matriz manual pendiente

| Escenario | Procedimiento y resultado esperado |
| --- | --- |
| Hover real con apps diarias | Bloc de notas, navegador, Explorer y editor: esperar entrada, salir por cada borde, comprobar rectángulo original |
| Dos monitores, DPI 100% + 150%/200% | Expandir en cada monitor; comprobar margen de 40/60/80 px y restauración sin desplazamiento |
| Monitor a izquierda/arriba y vertical | Probar coordenadas negativas y pantalla vertical; ningún margen desaparece |
| Desconexión/docking | Desconectar el monitor con expansión activa; terminar expansión y conservar una ventana accesible |
| Barra de tareas arriba/izquierda/autooculta | Repetir 20 ciclos y verificar que no hay deriva ni pérdida de margen |
| FancyZones activo | Distribución y arrastre con Shift, Win+flechas, cambio de layout y recolocación al cambiar resolución |
| Menús, IME, ventanas emergentes | Menús de app y diálogos fuera del borde deben permitir interacción sin restauración prematura |
| Atajos físicos | H/P/R, conflicto con otro programa y repetición mantenida; la UI informa conflictos |
| Bloqueo, suspensión y escritorio remoto | Restauración cuando Windows lo permita y journal intacto si no puede completarse |
| Cierre forzado de HoverFlow | Expandir una ventana de prueba, terminar HoverFlow y reiniciarlo; restaurar solo la misma identidad |
| Aplicación bloqueada durante SetWindowPos | Registrar posible espera de UI; nunca borrar la recuperación pendiente para ocultar el fallo |
| Accesibilidad | Narrador, teclado sin ratón, alto contraste y escalado 125–300%; la versión actual usa una paleta oscura fija |
| Windows 10 y ARM64 | Compatibilidad objetivo de Windows 10 y ejecución ARM64 aún no comprobadas físicamente |

No se presenta esta matriz como aprobada. Geometría sintética y declaraciones de DPI no sustituyen las pruebas de hardware. Si una aplicación concreta reajusta su tamaño, usa exclusiones y adjunta una reproducción mínima a una incidencia.
