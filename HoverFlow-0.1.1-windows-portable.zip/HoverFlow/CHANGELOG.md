# Changelog

## 0.1.1 — 2026-10-07

- Corregido el rechazo de ventanas normales que ocupan toda la altura o anchura de una zona de FancyZones/Snap: se permite reducir una dimensión para dejar el margen cuando el área total aumenta al menos un 5%.
- Esperas predeterminadas de 180 ms al expandir y 140 ms al restaurar; sondeo de 25 ms. Se permite configurar hasta 50 ms.
- El cooldown se limita a reactivar la misma ventana; cambiar a otra ventana requiere solo su retardo de entrada.
- Migración de los tiempos antiguos una sola vez, preservando margen, exclusiones y tiempos que ya fueran más rápidos. Botón **Use fast timing** para volver al perfil rápido.
- Se admiten ventanas independientes redimensionables con «siempre visible» y diálogos independientes redimensionables. Se mantiene el orden de apilamiento y se omiten ventanas emergentes con propietario.
- Mensajes de estado que explican filtros como ventana maximizada, no redimensionable, excluida o modo de ventana activa.
- Pruebas de regresión para geometría de zonas, migración, rapidez, cooldown y estado topmost.

## 0.1.0 — 2026-10-07

Primera versión preliminar.

- Expansión por hover con perímetro de salida de 16–240 DIP y restauración geométrica.
- Retardos, cooldown, exclusiones, modo de ventana activa y pin temporal.
- Bandeja, atajos globales, instancia única y preferencias persistentes.
- Identidad de HWND con propiedad temporal, journal y recuperación al reiniciar.
- Cesión a movimientos manuales y tratamiento conservador de cambios de monitor/sesión.
- Interfaz WPF en inglés y documentación en español con guía breve en inglés.
- Compilación sin descargas, pruebas unitarias/nativas y paquete portátil.

Limitaciones: sin firma, instalador ni autoactualización; FancyZones y hardware de varios monitores con DPI diferentes requieren validación manual adicional. Consulta TESTING.md y ARCHITECTURE.md.
