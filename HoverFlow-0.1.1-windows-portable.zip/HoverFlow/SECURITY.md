# Seguridad y privacidad

HoverFlow se ejecuta con los permisos del usuario. No requiere administrador, red, telemetría, entrada sintética ni lectura del contenido de documentos. Usa APIs de Windows para inspeccionar el cursor, estilos y geometría, y para mover ventanas elegibles.

La versión 0.1.1 es preliminar. Los cambios de seguridad se incorporarán a la siguiente versión publicada. No existe una promesa de soporte prolongado ni un servicio de actualización automática.

Si publicas este repositorio en GitHub, habilita **Private vulnerability reporting** en Settings → Code security antes de distribuirlo. Para un fallo sensible, usa Security → Report a vulnerability cuando esté disponible. No publiques pruebas con datos privados en un issue abierto. Si ese canal no está habilitado, solicita al mantenedor un canal privado sin revelar detalles de explotación.

Incluye versión, Windows, pasos mínimos, impacto y una reproducción sin información personal. No hay un correo de seguridad asignado todavía.

Los archivos de preferencias y recuperación están en el perfil del usuario. No deben considerarse una frontera contra software malicioso que ya pueda escribir allí o manipular ventanas con los mismos permisos. El token de ventana protege frente a handles reciclados accidentales. La recuperación es conservadora y no fuerza coordenadas cuando detecta cambios externos.

El ejecutable se entrega sin firma digital. Verifica el hash de la entrega o compila desde código revisado. No desactives el antivirus ni ejecutes con elevación para sortear una restricción.
