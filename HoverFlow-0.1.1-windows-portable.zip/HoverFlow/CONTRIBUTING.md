# Contribuir a HoverFlow

Gracias por contribuir. Usa issues para describir problemas concretos y pull requests pequeños para corregirlos. No incluyas credenciales, títulos/documentos privados ni registros sin revisar.

## Preparación

Lee [BUILD.md](docs/BUILD.md) y [ARCHITECTURE.md](docs/ARCHITECTURE.md). Compila con `build.ps1 -Test`. Antes de cambiar el motor Win32, ejecuta también `-NativeTest` en una sesión de escritorio y la matriz manual relevante de [TESTING.md](docs/TESTING.md).

El código se mantiene compatible con el compilador de .NET Framework 4.x. Evita sintaxis reciente o nuevas dependencias sin discutir primero la migración. Usa cuatro espacios, nombres descriptivos y pruebas que describan comportamiento observable. El motor debe seguir siendo independiente de WPF y Win32.

## Invariantes de producto

- Siempre debe existir un margen de salida. No se permite configurar cero ni maximizar como sustituto de expandir.
- Guardar identidad y rectángulo antes de mover. No borrar una recuperación pendiente por comodidad.
- No robar foco, cambiar el orden Z o forzar una disposición después de una acción manual.
- No tocar configuraciones ni atajos de otros gestores.
- No añadir inicio automático, telemetría o acceso de red silenciosamente.

Una PR debe describir el problema, la conducta resultante, las pruebas ejecutadas y los límites no probados. Actualiza la documentación cuando cambie el flujo visible, la configuración o el formato del journal. Para cambios de interfaz adjunta una captura del render real y revisa navegación por teclado y escalado.
